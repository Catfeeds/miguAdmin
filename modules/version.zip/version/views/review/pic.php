<img src="<?php echo $pic?>">

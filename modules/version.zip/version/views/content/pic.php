<script type="text/javascript" src="/js/uploadify/jquery.uploadify.min.js"></script>
<form action="" method="post" enctype="multipart/form-data">
    <img src="<?php echo $url?>">
</form>


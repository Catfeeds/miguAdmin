<form action="" method="post" enctype="multipart/form-data">
    <table class="mtable"  cellpadding="10" cellspacing="0">
        <input type="hidden" name="vid" value="<?php echo !empty($id)?$id:''?>">
        <tr>
            <td width="100" align="right">关键词：</td>
            <td><input type="text" name="vname" value="<?php echo !empty($keyword->attributes['keyword'])?$keyword->attributes['keyword']:'';?>" class="form-input"></td>
        </tr>
        <tr>
            <td width="100" align="right">节目类型：</td>
            <td>
                <select name="type" class="form-input w100" id="vtype" >
                    <option <?php $type = !empty($keyword->attributes['type'])?$keyword->attributes['type']:'';if($type=='0'){echo "selected=selected";}?> value="0">请选择</option>
                    <option <?php $type = !empty($keyword->attributes['type'])?$keyword->attributes['type']:'';if($type=='电影'){echo "selected=selected";}?> value="电影" >电影</option>
                    <option <?php $type = !empty($keyword->attributes['type'])?$keyword->attributes['type']:'';if($type=='综艺'){echo "selected=selected";}?> value="综艺">综艺</option>
                    <option <?php $type = !empty($keyword->attributes['type'])?$keyword->attributes['type']:'';if($type=='新闻'){echo "selected=selected";}?> value="新闻">新闻</option>
                    <option <?php $type = !empty($keyword->attributes['type'])?$keyword->attributes['type']:'';if($type=='电视剧'){echo "selected=selected";}?> value="电视剧">电视剧</option>
                    <option <?php $type = !empty($keyword->attributes['type'])?$keyword->attributes['type']:'';if($type=='动漫'){echo "selected=selected";}?> value="动漫">动漫</option>
                    <option <?php $type = !empty($keyword->attributes['type'])?$keyword->attributes['type']:'';if($type=='教育'){echo "selected=selected";}?> value="教育">教育</option>
                    <option <?php $type = !empty($keyword->attributes['type'])?$keyword->attributes['type']:'';if($type=='体育'){echo "selected=selected";}?> value="体育">体育</option>
                    <option <?php $type = !empty($keyword->attributes['type'])?$keyword->attributes['type']:'';if($type=='音乐'){echo "selected=selected";}?> value="音乐">音乐</option>
                    <option <?php $type = !empty($keyword->attributes['type'])?$keyword->attributes['type']:'';if($type=='记录'){echo "selected=selected";}?> value="记录">记录</option>
                    <option <?php $type = !empty($keyword->attributes['type'])?$keyword->attributes['type']:'';if($type=='其他'){echo "selected=selected";}?> value="其他">其他</option>
                </select>
            </td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td>
                <input type="submit" value="保存信息" class="btn classify_btn">
                <input type="button" value="返回列表" class="gray">
            </td>
        </tr>
    </table>
</form>
<script>
    $('.classify_btn').click(function(){
        var G={};
        G.id = $('input[name=vid]').val();
        G.type = $('#vtype').val();
        G.name = $('input[name=vname]').val();
        if(empty(G.name)){
            layer.alert('关键词不能为空');
            return false;
        }
        $.post("<?php echo $this->get_url('content','keysub')?>",G,function(d){
            location.reload();
        })
        return false;
    })

    $('.gray').click(function(){
        layer.closeAll();
    })
</script>


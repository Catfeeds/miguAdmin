<script charset="utf-8" type="text/javascript" src="/js/jdate/jquery.datetimepicker.js"></script>
<link rel="stylesheet" href="/js/jdate/jquery.datetimepicker.css" />
<form action="" method="post" enctype="multipart/form-data">
<table class="mtable" width="50%" cellspacing="0" cellpadding="10">
    <input type="hidden" name="id" value="<?php echo !empty($message->attributes['id'])?$message->attributes['id']:''?>">
    <tr>
        <td width="100" align="right">标题：</td>
        <td><input type="text" name="title" id="title" value="<?php echo !empty($message->attributes['title'])?$message->attributes['title']:''?>" class="form-input w300">
        </td>
    </tr>
    <tr>
        <td width="100" align="right">推荐内容：</td>
        <td>
            <select name="type" class="form-input w300" id="type" onchange="aa()">
                <option value="0">请选择</option>
                <option <?php $type= !empty($message->attributes['type'])?$message->attributes['type']:'';if($type=='1'){echo "selected=selected"; }?> value="1" >咪咕</option>
                <option <?php $type= !empty($message->attributes['type'])?$message->attributes['type']:'';if($type=='2'){echo "selected=selected"; }?> value="2" >应用</option>
                <option <?php $type= !empty($message->attributes['type'])?$message->attributes['type']:'';if($type=='3'){echo "selected=selected"; }?>  value="3" >牌照方</option>
                <option <?php $type= !empty($message->attributes['type'])?$message->attributes['type']:'';if($type=='4'){echo "selected=selected"; }?> value="4" >第三方</option>
            </select>
        </td>
    </tr>
    <tr id="show" style="display:none">
        <td width="100" align="right">牌照方：</td>
        <td>
            <select name="cp" class="form-input w300" id="cp">
                <option value="0">请选择</option>
                <option <?php $cp= !empty($message->attributes['cp'])?$message->attributes['cp']:'';if($cp=='1'){echo "selected=selected"; }?> value="1">华数客户端</option>
                <option <?php $cp= !empty($message->attributes['cp'])?$message->attributes['cp']:'';if($cp=='2'){echo "selected=selected"; }?> value="2">百视通客户端</option>
                <option <?php $cp= !empty($message->attributes['cp'])?$message->attributes['cp']:'';if($cp=='3'){echo "selected=selected"; }?> value="3">未来电视</option>
                <option <?php $cp= !empty($message->attributes['cp'])?$message->attributes['cp']:'';if($cp=='4'){echo "selected=selected"; }?> value="4">南传</option>
                <option <?php $cp= !empty($message->attributes['cp'])?$message->attributes['cp']:'';if($cp=='7'){echo "selected=selected"; }?> value="7">银河</option>
            </select>
        </td>
    </tr>
    <tr class="utp" style="display:none">
        <td width="100" align="right">页面类型</td>
        <td><select name="uType" class="form-input w300" id="uType">
                <option value="0">请选择</option>
                <option <?php $uType= !empty($message->attributes['uType'])?$message->attributes['uType']:'';if($uType=='1'){echo "selected=selected"; }?> value="1">搜索</option>
                <option <?php $uType= !empty($message->attributes['uType'])?$message->attributes['uType']:'';if($uType=='2'){echo "selected=selected"; }?> value="2">栏目</option>
                <option <?php $uType= !empty($message->attributes['uType'])?$message->attributes['uType']:'';if($uType=='4'){echo "selected=selected"; }?> value="4">专题</option>
                <option <?php $uType= !empty($message->attributes['uType'])?$message->attributes['uType']:'';if($uType=='5'){echo "selected=selected"; }?> value="5">收藏</option>
                <option <?php $uType= !empty($message->attributes['uType'])?$message->attributes['uType']:'';if($uType=='6'){echo "selected=selected"; }?>  value="6">历史</option>
                <option <?php $uType= !empty($message->attributes['uType'])?$message->attributes['uType']:'';if($uType=='7'){echo "selected=selected"; }?> value="7">电影详情页</option>
                <option <?php $uType= !empty($message->attributes['uType'])?$message->attributes['uType']:'';if($uType=='8'){echo "selected=selected"; }?> value="8">电视剧详情页</option>
                <option <?php $uType= !empty($message->attributes['uType'])?$message->attributes['uType']:'';if($uType=='9'){echo "selected=selected"; }?> value="9">新闻详情页</option>
                <option <?php $uType= !empty($message->attributes['uType'])?$message->attributes['uType']:'';if($uType=='10'){echo "selected=selected"; }?> value="10">综艺详情页</option>
                <option <?php $uType= !empty($message->attributes['uType'])?$message->attributes['uType']:'';if($uType=='11'){echo "selected=selected"; }?> value="11">设置</option>
                <option <?php $uType= !empty($message->attributes['uType'])?$message->attributes['uType']:'';if($uType=='12'){echo "selected=selected"; }?> value="12">壁纸</option>
            </select></td>
    </tr>
    <tr class="act" style="display:none">
        <td width="100" align="right">action：</td>
        <td><input type="text" name="action" id="action" value="<?php echo !empty($message->attributes['action'])?$message->attributes['action']:''?>" class="form-input"></td>
    </tr>
    <tr  class="act" style="display:none">
        <td width="100" align="right">param：</td>
        <td><input type="text" name="param" id="param" value="<?php echo !empty($message->attributes['param'])?$message->attributes['param']:''?>" class="form-input"></td>
    </tr>
    <tr  class="upvid" style="display:none">
        <td width="100" align="right">vid：</td>
        <td><input type="text" id="upvid" name="upvid" value="<?php echo !empty($message->attributes['vid'])?$message->attributes['vid']:''?>" class="form-input"></td>
    </tr>
    <tr style="display:none" class="pic">
        <td width="100" align="right">pic：</td>
        <td><input type="text" name="pic" id="pic" value="<?php echo !empty($message->attributes['pic'])?$message->attributes['pic']:''?>" class="form-input w400"></td>
    </tr>
    <tr>
        <td width="100" align="right">内容：</td>
        <td><textarea name="info" class="form-input w400" style="height:200px;resize: none;"><?php echo !empty($message->attributes['info'])?$message->attributes['info']:''?></textarea></td>
    </tr>
    <tr>
        <td>有效期</td>
        <td><input type="text" name="firstTime" id="firstTime" value="<?php $first=!empty($message->attributes['firstTime'])?$message->attributes['firstTime']:''; if(!empty($first)){echo date("Y-m-d",$first);}?>" class="form-input w100">--<input type="text" name="endTime" id="endTime" value="<?php $end=!empty($message->attributes['endTime'])?$message->attributes['endTime']:''; if(!empty($end)){echo date("Y-m-d",$end);}?>" class="form-input w100"></td>
    </tr>
    <tr>
        <td align="center" colspan="2">
            <input type="submit" value="保存信息" class="btn save">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="button" value="取消" class="gray" onclick="window.location.href='<?php echo $this->get_url('content','msgindex')?>'">
        </td>
    </tr>
</table>
</form>
<script>

    $('#firstTime,#endTime').datetimepicker({
        lang:'ch',
        validateOnBlur:false,
        timepicker:false,
        format:'Y-m-d',
        formatDate: 'Y-m-d',
    });

    $('.save').click(function(){
        var first = $('input[name=firstTime]').val();
        if(empty(first)){
            layer.alert("请填写有效期！")
            return false;
        }
        var timeend = $('input[name=endTime]').val();
        if(empty(timeend)){
            layer.alert("请填写有效期！")
            return false;
        }
    })

    $(function(){
        aa();
    })
    function aa(){
        var zhi = $('#type').val();
        switch(zhi){
            case '1':
                $('#show').hide();
                $('.act').hide();
                $('.utp').show();
                $('.upvid').show();
                break;
            case '2':
                $('#show').hide();
                $('.utp').hide();
                $('.upvid').hide();
                $('.act').show();
                break;
            case '3':
                $('#show').show();
                $('.utp').hide();
                $('.upvid').hide();
                $('.act').show();
                break;
            case '4':
                $('#show').hide();
                $('.utp').hide();
                $('.upvid').hide();
                $('.act').show();
                break;
        }

    }
</script>

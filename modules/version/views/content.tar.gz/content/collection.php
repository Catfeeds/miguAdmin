<script type="text/javascript" src="/js/uploadify/jquery.uploadify.min.js"></script>
<style>
    td{font-size: 12px}
</style>
<div class="mt10" style="width:400px">
    <form action="" method="post">
        <input type="hidden" name="vid" value="<?php echo !empty($vid)?$vid:''?>">
        <table border="1" width="600px">
            <tr>
                <td>资产名称:</td>
                <td colspan="3"><input type="text" name="title" class="form-input w400" value="<?php echo !empty($_GET['title'])?$_GET['title']:''?>" style="height:25px;line-height: 25px"></td>
            </tr>
            <tr>
                <td>内容类型:</td>
                <td>Collection</td>
            </tr>
            <tr>
                <td>节目类型:</td>
                <td><select name="type" class="form-input w100" id="type">
                        <option value="0">请选择</option>
                        <option  value="电影" >电影</option>
                        <option  value="综艺">综艺</option>
                        <option  value="新闻">新闻</option>
                        <option  value="电视剧">电视剧</option>
                        <option  value="动漫">动漫</option>
                        <option  value="教育">教育</option>
                        <option  value="体育">体育</option>
                        <option  value="音乐">音乐</option>
                        <option  value="记录">记录</option>
                        <option  value="生活">生活</option>
                        <option  value="其他">其他</option>
                    </select></td>
                <td>内容提供商:</td>
                <td>华数</td>
            </tr>
            <tr>
                <td>内容ID:</td>
                <td></td>
                <td>资产ID:</td>
                <td></td>
            </tr>
            <tr>
                <td>版权开始时间:</td>
                <td><input type="text" class="form-input w100" name="startDateTime" value=""></td>
                <td>版权结束时间:</td>
                <td><input type="text" class="form-input w100" name="endDateTime" value=""></td>
            </tr>
            <tr>
                <td>看点:</td>
                <td colspan="3"><textarea name="info" cols="65" rows="10" style="border:1px solid grey"></textarea></td>
            </tr>
            <tr>
                <td>优先级:</td>
                <td><select name="orders" class="form-input w100" id="orders">
                        <option value="0">请选择</option>
                        <option  value="1" >1</option>
                        <option  value="2">2</option>
                        <option  value="3">3</option>
                        <option  value="4">4</option>
                        <option  value="5">5</option>
                        <option  value="6">6</option>
                        <option  value="7">7</option>
                        <option  value="8">8</option>
                        <option  value="9">9</option>
                        <option  value="10">10</option>
                    </select></td>
                <td>首字母:</td>
                <td><input type="text" name="initial" class="form-input w100" value="" style="height:25px;line-height: 25px"></td>
            </tr>
            <tr>
                <td>国家地区:</td>
                <td><select name="CountryOfOrigin" class="form-input w100" id="CountryOfOrigin">
                        <option value="0">请选择</option>
                        <option  value="1" >内地</option>
                        <option  value="2">港台</option>
                        <option  value="3">韩日</option>
                        <option value="4">欧美</option>
                        <option  value="5">东南亚</option>
                        <option  value="99">其他</option>
                    </select></td>
                <td>发行年份:</td>
                <td><input type="text" name="year" class="form-input w100" value="" style="height:25px;line-height: 25px"></td>
            </tr>
            <tr>
                <td>配音语言:</td>
                <td><input type="text" class="form-input w100" name="language" value="" style="height:25px;line-height: 25px"></td>
                <td>字幕语言:</td>
                <td><select name="subtitles" class="form-input w100" id="subtitles">
                        <option value="0">请选择</option>
                        <option  value="中文" >中文</option>
                        <option  value="英文">英文</option>
                        <option  value="日语">日语</option>
                        <option  value="法语">法语</option>
                        <option  value="其他">其他</option>
                    </select></td>
            </tr>
            <tr>
                <td>评分</td>
                <td><input type="text" class="form-input w100" name="score" value="" style="height:25px;line-height: 25px;"></td>
                <td>清晰度</td>
                <td><input type="text" class="form-input w100"  style="height:25px;line-height: 25px;"></td>
            </tr>
            <tr>
                <td>关键词:</td>
                <td colspan="3"><input type="text" class="form-input w400" name="keyword" value="" style="height:25px;line-height: 25px"></td>
            </tr>
            <tr class="num" style="display:none">
                <td>更新集数:</td>
                <td colspan="3"><input type="text" class="form-input w400" name="num" value="" style="height:25px;line-height: 25px;"></td>
            </tr>
            <tr class="end">
                <td>是否完结:</td>
                <td><label for="noCharge"><input type="radio" name="end" id="noCharge" value="1" />是</label>
                    <label for="charge"><input type="radio" name="end" id="charge" value="2" />否</label></td>
            </tr>
            <tr class="act">
                <td>导演:</td>
                <td colspan="3"><input type="text" class="form-input w400" name="director" value="" style="height:25px;line-height: 25px;"></td>

            </tr>
            <tr class="act">
                <td>演员:</td>
                <td colspan="3"><input type="text" class="form-input w400" name="actor" value="" style="height:25px;line-height: 25px;"></td>
            </tr>
            <tr class="pri" style="display:none">
                <td>奖项:</td>
                <td><input type="text" class="form-input w100" name="prize" value="" style="height:25px;line-height: 25px;"></td>
                <td>票房:</td>
                <td><input type="text" class="form-input w100" name="boxoffice" value="" style="height:25px;line-height: 25px;"></td>
            </tr>
            <tr class="com" style="display:none">
                <td>影评:</td>
                <td><input type="text" class="form-input w100" name="comment" value="" style="height:25px;line-height: 25px;"></td>
            </tr>
        </table>

        <input type="submit" class="btn" value="提交" >
    </form>
</div>
<script>

</script>


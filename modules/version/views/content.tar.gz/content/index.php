<script charset="utf-8" type="text/javascript" src="/js/jdate/jquery.datetimepicker.js"></script>
<link rel="stylesheet" href="/js/jdate/jquery.datetimepicker.css" />
<div class="mt10">
    <form action="">
        <input type="text" name="title"  class="form-input w100" value="<?php echo !empty($_GET['title'])?$_GET['title']:''?>" placeholder="请输入标题">
       <select name="cp" class="form-input w100" id="cp">
            <option value="0">请选择</option>
            <option <?php $cp=!empty($_GET['cp'])?$_GET['cp']:'';if($cp=='642001'){echo "selected=selected"; } ?> value="642001" >华数</option>
            <option <?php $cp=!empty($_GET['cp'])?$_GET['cp']:'';if($cp=='BESTVOTT'){echo "selected=selected"; } ?> value="BESTVOTT">百视通</option>
            <option <?php $cp=!empty($_GET['cp'])?$_GET['cp']:'';if($cp=='ICNTV'){echo "selected=selected"; } ?> value="ICNTV">未来电视</option>
            <option <?php $cp=!empty($_GET['cp'])?$_GET['cp']:'';if($cp=='youpeng'){echo "selected=selected"; } ?> value="youpeng">南传</option>
            <option <?php $cp=!empty($_GET['cp'])?$_GET['cp']:'';if($cp=='HNBB'){echo "selected=selected"; } ?> value="HNBB">芒果</option>
            <option <?php $cp=!empty($_GET['cp'])?$_GET['cp']:'';if($cp=='CIBN'){echo "selected=selected"; } ?> value="CIBN">国广</option>
            <option <?php $cp=!empty($_GET['cp'])?$_GET['cp']:'';if($cp=='YGYH'){echo "selected=selected"; } ?> value="YGYH">银河</option>
        </select> 
        <select name="ShowType" class="form-input w100" id="ShowType">
            <option value="0">请选择</option>
            <option <?php $ShowType=!empty($_GET['ShowType'])?$_GET['ShowType']:'';if($ShowType=='Movie'){echo "selected=selected"; } ?> value="Movie" >Movie</option>
            <option <?php $ShowType=!empty($_GET['ShowType'])?$_GET['ShowType']:'';if($ShowType=='Column'){echo "selected=selected"; } ?> value="Column">Column</option>
            <option <?php $ShowType=!empty($_GET['ShowType'])?$_GET['ShowType']:'';if($ShowType=='News'){echo "selected=selected"; } ?> value="News">News</option>
            <option <?php $ShowType=!empty($_GET['ShowType'])?$_GET['ShowType']:'';if($ShowType=='Series'){echo "selected=selected"; } ?> value="Series">Series</option>
            <option <?php $ShowType=!empty($_GET['ShowType'])?$_GET['ShowType']:'';if($ShowType=='Collection'){echo "selected=selected"; } ?> value="Collection">Collection</option>
        </select>
        <select name="flag" class="form-input w100" id="flag">
            <option value="">请选择</option>
            <option <?php if(isset($_GET['flag'])){
                      if($_GET['flag']=='0'){
                          echo "selected=selected";
                      }
		} ?> value="0">不通过</option>
            <option <?php $flag=!empty($_GET['flag'])?$_GET['flag']:'';if($flag=='1'){echo "selected=selected"; } ?> value="1" >审核中</option>
            <option <?php $flag=!empty($_GET['flag'])?$_GET['flag']:'';if($flag=='2'){echo "selected=selected"; } ?> value="2">通过</option>
        </select>
        <span>开始日期</span>
        <input  type="text" name="first" id="first" class="form-input w100" value="<?php echo !empty($_GET['first'])?$_GET['first']:''?>">
        <span>结束日期</span>
        <input type="text" name="timeend" id="timeend" class="form-input w100" value="<?php echo !empty($_GET['timeend'])?$_GET['timeend']:''?>">
        <input class="btn btn1 btn-gray audit_search search " type="button" value="查找" name="" style="font-size: 14px">
    <br>
    <input class="form-input w100" type="text" value="" name="collection"  >
        <input class="btn collection_add" type="button" value="添加栏目集" name="collection_add" style="font-size: 14px">
    <input class="btnall btn" type="button" value="全选">
        <input class="btnno btn" type="button" value="全不选">
    <input class="btn sub_btn" type="button" value="提交审核">
    <table width="100%" cellspacing="0" cellpadding="10" class="mtable center">
        <tr>
            <th>编号</th>
            <th>资产ID</th>
            <th>牌照方</th>
            <th>标题</th>
            <th>类型</th>
            <th>语言</th>
            <th>状态</th>
            <th>添加时间</th>
            <th>最后修改时间</th>
            <th>操作</th>
        </tr>
        <?php
        if(!empty($list)){
            foreach($list as $l){?>
                <tr>
                    <input type="hidden" value="<?php echo $l['vid']?>">
                    <td><input type="checkbox" class="checkbox" name="id" value="<?php echo $l['id']?>"></td>
                    <td><?php echo $l['vid']?></td>
                    <td><?php
                        switch($l['cp']){
                            case '642001':echo '华数';break;
                            case 'BESTVOTT':echo '百视通';break;
                            case 'ICNTV':echo '未来电视';break;
                            case 'youpeng':echo '南传';break;
                            case 'HNBB':echo '芒果';break;
                            case 'CIBN':echo '国广';break;
                            case 'YGYH':echo '银河';break;
                        }
                        ?></td>
                    <td><?php echo $l['title']?></td>
                    <td><?php switch($l['ShowType']){
                            case 'Movie':echo '电影';break;
                            case 'Column':echo '栏目';break;
                            case 'News':echo '新闻';break;
                            case 'Series':echo '电视剧';break;
                            } 
                            ?></td>
                    <td><?php echo $l['language']?></td>
                    <td><?php switch($l['flag']){
                             case '0':echo '不通过';break;
                             case '1':echo '审核中';break;
                             case '2':echo '通过';break;
                        }?></td>
                    <td><?php echo date('Y-m-d H:i',$l['cTime'])?></td>
                    <td><?php 
                        if(empty($l['upTime'])){
                           echo '';
                        }else{
                            echo date('Y-m-d H:i',$l['upTime']);
                        }
                    ?></td>
                    <td>
                        <a href="#" class="add">编辑</a>
                        <?php
                            if($l['flag']=='0'){
                                echo "<a href='javascript:void(0)' gid='{$l['id']}' class='review'>提交审核</a>";
                            }elseif($l['flag']=='2'){
                                echo "<a href='javascript:void(0)' gid='{$l['id']}' class='access'>入库</a>";
                            }elseif($l['flag']=='3'){
                                echo "<a href='javascript:void(0)' gid='{$l['id']}' class='fff'>下线</a>";
                            }
                        ?>
                    </td>
                </tr>
                <?php
            }
        }
        ?>
    </table>
    </form>
</div>
<div><?php echo $page;?><div style="float:right;margin-top:-60px;margin-right:30px"><input type="text" class="form-input w100" value="" name="page"><input type="button" class="btn page_btn" value="输入页码跳转"></div></div>
<script>
    $('.btnall').click(function(){
        $(".center :checkbox").prop("checked", true);
    })
    $('.btnno').click(function(){
        $(".center :checkbox").prop("checked", false);
    })
    $('#first,#timeend').datetimepicker({
        lang:'ch',
        validateOnBlur:false,
        timepicker:false,
        format:'Y-m-d',
        formatDate: 'Y-m-d',
        maxDate:'<?php echo date('Y-m-d',strtotime('1 day'))?>'
    });
    $('.add').click(function(){
        var vid = $(this).parent().parent().children('input').val();
        var id = $(this).parent().siblings().children('input').val();
        var mid = "<?php echo $this->mid?>";
        url="/version/content/add?vid="+vid+"&id="+id+"&mid="+mid;
        window.open(url);
    })

    $('.search').click(function(){
        var title = $('input[name=title]').val();
        var cp = $('#cp').val();
        var ShowType = $('#ShowType').val();
        var flag = $('#flag').val();
        var first = $('input[name=first]').val();
        var timeend = $('input[name=timeend]').val();
        var mid = "<?php echo $this->mid?>";
        //var nid = "<?php echo !empty($_REQUEST['nid'])?$_REQUEST['nid']:''?>";
        window.location.href="/version/content/index?mid="+mid+"&ShowType="+ShowType+"&cp="+cp+"&title="+title+"&flag="+flag+"&first="+first+"&timeend="+timeend;
    })

    $('.review').click(function(){
        var gid = $(this).attr('gid');
        $.post("<?php echo $this->get_url('review','add')?>",{gid:gid},function(d){
            location.reload();
        })
    })

    $('.access').click(function(){
        var gid = $(this).attr('gid');
        $.post("<?php echo $this->get_url('content','access')?>",{gid:gid},function(d){
            location.reload();
        })
    })

    $('.page_btn').click(function(){
        var title = $('input[name=title]').val();
        var cp = $('#cp').val();
        var ShowType = $('#ShowType').val();
        var page = $('input[name=page]').val();
        switch(cp){
            case '华数':cp='642001';break;
            case '百视通':cp='BESTVOTT';break;
            case '未来电视':cp='ICNTV';break;
            case '南传':cp='youpeng';break;
            case '芒果':cp='HNBB';break;
            case '国广':cp='CIBN';break;
            case '银河':cp='YGYH';break;
        }
        var flag = $('#flag').val();
        var first = $('input[name=first]').val();
        var timeend = $('input[name=timeend]').val();
        var mid = "<?php echo $this->mid?>";
        //var nid = "<?php echo !empty($_REQUEST['nid'])?$_REQUEST['nid']:''?>";
        window.location.href="/version/content/index?mid="+mid+"&ShowType="+ShowType+"&cp="+cp+"&title="+title+"&page="+page+"&flag="+flag+"&first="+first+"&timeend="+timeend;
    })
    $('.collection_add').click(function(){
        var title = $('input[name=collection]').val();
        if(empty(title)){
            layer.alert('标题不能为空',{icon:0});
            return false;
        }
        var mid = "<?php echo $this->mid?>";
        url="/version/content/collection?mid="+mid+"&title="+title;
        window.open(url);
    })
    $('.sub_btn').click(function(){
        var ids="";
        $("input[name='id']:checked").each(function() {

            ids += $(this).val()+' ';

        });
        $.post("<?php echo $this->get_url('content','subrev')?>",{ids:ids},function(d){
            location.reload();
        })
    })
</script>

<script charset="utf-8" type="text/javascript" src="/js/jdate/jquery.datetimepicker.js"></script>
<link rel="stylesheet" href="/js/jdate/jquery.datetimepicker.css" />
<div class="mt10">
    <form action="">
        节目类型:
        <select name="type" class="form-input w100" id="type">
            <option value="0">请选择</option>
            <option value="电影" >电影</option>
            <option value="综艺">综艺</option>
            <option value="新闻">新闻</option>
            <option value="电视剧">电视剧</option>
            <option value="动漫">动漫</option>
            <option value="教育">教育</option>
            <option value="体育">体育</option>
            <option value="音乐">音乐</option>
            <option value="记录">记录</option>
            <option value="其他">其他</option>
        </select>
        <input class="btn btn_search" value="查询" type="button">
        <input class="btn keyadd" value="新建关键字" type="button" style="float: right;">
        <table width="100%" cellspacing="0" cellpadding="10" class="mtable center">
            <tr>
                <th>编号</th>
                <th>节目类型</th>
                <th>关键字</th>
                <th>创建时间</th>
                <th>操作</th>
            </tr>
            <?php
                if(!empty($list)){
                    foreach( $list as $k=>$v){
                        ?>
                        <tr>
                            <input type="hidden" value="<?php echo $v['id']?>" name="id">
                            <td><?php echo $v['id']?></td>
                            <td><?php echo $v['type']?></td>
                            <td><?php echo $v['keyword']?></td>
                            <td><?php echo date('Y-m-d',$v['cTime'])?></td>
                            <td><a class="edit">编辑</a>&nbsp;<a class="del">删除</a></td>
                        </tr>
                    <?php
                    }
                }
            ?>
        </table>
    </form>
</div>
<script>
    $('.keyadd').click(function(){
        $.getJSON('<?php echo $this->get_url('content','keyadd')?>',function(d){
            if(d.code == 200){
                layer.open({
                    type: 1,
                    skin: 'layui-layer-rim', //加上边框
                    area: ['530px', '350px'], //宽高
                    content: d.msg
                })
            }else{
                layer.alert(d.msg,{icon:0});
            }
        })
    })

    $('.edit').click(function(){
        var id = $(this).parent().parent().children('input').val();
        $.getJSON('<?php echo $this->get_url('content','keyadd')?>',{id:id},function(d){
            if(d.code == 200){
                layer.open({
                    type: 1,
                    skin: 'layui-layer-rim', //加上边框
                    area: ['530px', '350px'], //宽高
                    content: d.msg
                })
            }else{
                layer.alert(d.msg,{icon:0});
            }
        })
    })

    $('.btn_search').click(function(){
        var type = $('#type').val();
        var mid = "<?php echo $this->mid?>";
        window.location.href="/version/content/keyword?mid="+mid+"&type="+type;
    })
    $('.del').click(function(){
        var id = $(this).parent().siblings('input').val();
        $.post('<?php echo $this->get_url('content','keydel')?>',{id:id},function(d){
            if(d.code==200){
                alert(d.msg);
                location.reload();
            }else{
                alert(d.msg);
            }
        },'json')
    })
</script>

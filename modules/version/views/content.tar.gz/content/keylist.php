<script charset="utf-8" type="text/javascript" src="/js/jdate/jquery.datetimepicker.js"></script>
<link rel="stylesheet" href="/js/jdate/jquery.datetimepicker.css" />
<div class="mt10">
    <form action="">
        节目类型:
        <select name="type" class="form-input w100" id="temtype">
            <option value="0">请选择</option>
            <option value="电影" >电影</option>
            <option value="综艺">综艺</option>
            <option value="新闻">新闻</option>
            <option value="电视剧">电视剧</option>
            <option value="动漫">动漫</option>
            <option value="教育">教育</option>
            <option value="体育">体育</option>
            <option value="音乐">音乐</option>
            <option value="记录">记录</option>
            <option value="其他">其他</option>
        </select>
        <input class="btn btn_search" value="查询" type="button">
        <input class="btn btn1 btn-gray btnall " type="button"  value="全选" name="" >
        <input class="btn btn1 btn-gray btnno " type="button"  value="反选" name="" >
        <input class="btn btn1 btn-gray btn_add " type="button"  value="添加" name="" >
        <div id="fenlei">
        <table width="100%" cellspacing="0" cellpadding="10" class="mtable keylist">
            <tr>
                <th>编号</th>
                <th>节目类型</th>
                <th>关键字</th>
                <th>创建时间</th>
                <th>操作</th>
            </tr>
        </table>
        </div>
        <div id="page"></div>
    </form>
</div>
<script>
    $('.btnall').click(function(){
        $("#fenlei :checkbox").prop("checked", true);
    })
    $('.btnno').click(function(){
        $("#fenlei :checkbox").prop("checked", false);
    })

    $('.btn_add').click(function(){
        var words='';
        /*var word =document.getElementsByName("word");
        for (var i = 0, j = word.length; i < j; i++) {
            if(i==0){
                words = word[i].value;
            }else{
                words += '/'+word[i].value;
            }

        }*/
        $('input[name="word"]:checked').each(function(){
            words += '/'+$(this).val();
        });
        console.log(words)
        $('.keyword').html(words);
        $('input[name=keyword]').val(words);
        layer.closeAll();
    })


    $('.btn_search').click(function(){
        getData(1)
    })

    function getData(page){
        var type = $('#temtype').val();
        $.ajax({
            type: 'GET',
            url: '/version/content/ajax?mid='+"<?php echo $_GET['mid']?>"+"&type="+type,
            data: {'page': page },
            dataType: 'json',
            success: function(json) {
                $("#fenlei").empty();
                //total_num = json.total_num;//总记录数
                //page_size = json.page_size;//每页数量
                //page_cur = page;//当前页
                page_total_num = json.page_total_num;//总页数
                var li = '<table class="mtable" width="100%" cellspacing="0" cellpadding="10"><tr><th>编号</th><th>节目类型</th><th>关键字</th><th>创建时间</th><th>操作</th></tr>';
                var list = json.list;
                $.each(list, function(index, array) { //遍历返回json
                    li += "<tr><td><input type='checkbox' class='checkbox' name='word' value="+array['keyword']+"></td><td>"+array['type']+"</td><td>"+array['keyword']+"</td><td>"+getLocalTime(array['cTime'])+"</td><td>添加</td></tr>";
                });
                if(list == '') li +='<tr><td  colspan="6" align="center">暂无数据</td></tr>';
                li += '</table>';
                $("#fenlei").append(li);
            },
            complete: function() {
                //getPageBar();//js生成分页，可用程序代替
            },
            error: function() {
                alert("数据异常,请检查是否json格式");
            }
        });
    }

    function getPageBar() { //js生成分页
        if (page_cur > page_total_num)
            page_cur = page_total_num;//当前页大于最大页数
        if (page_cur < 1)
            page_cur = 1;//当前页小于1
        page_str = "<span>共" + total_num + "条</span><span>" + page_cur + "/" + page_total_num + "</span>";
        if (page_cur == 1) {//若是第一页
            page_str += "<span>首页</span><span>上一页</span>";
        } else {
            page_str += "<span><a href='javascript:void(0)' data-page='1' onclick=getData(1)>首页</a></span><span><a href='javascript:void(0)' data-page='" + (page_cur - 1) + "' onclick=getData("+ (parseInt(page_cur) - 1) +")>上一页</a></span>";
        }
        if (page_cur >= page_total_num) {//若是最后页
            page_str += "<span>下一页</span><span>尾页</span>";
        } else {
            page_str += "<span><a href='javascript:void(0)' data-page='" + (parseInt(page_cur) + 1) + "' onclick=getData("+ (parseInt(page_cur) + 1) +") >下一页</a></span><span><a href='javascript:void(0)' data-page='" + page_total_num + "'  onclick=getData("+ (page_total_num) +")>尾页</a></span>";
        }
        $("#page").html(page_str);
    }
    function getLocalTime(nS) {
        return new Date(parseInt(nS) * 1000).toLocaleString().replace(/:\d{1,2}$/,' ');
    }
</script>
